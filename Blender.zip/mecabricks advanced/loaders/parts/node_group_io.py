import bpy


def create_group_input(tree, type, name):
    if bpy.app.version < (4, 0, 0):
        tree.inputs.new(type, name)
    else:
        tree.interface.new_socket(name=name, socket_type=type, in_out='INPUT')


def create_group_output(tree, type, name):
    if bpy.app.version < (4, 0, 0):
        tree.outputs.new(type, name)
    else:
        tree.interface.new_socket(name=name, socket_type=type, in_out='OUTPUT')
